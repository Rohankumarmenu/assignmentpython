import pdfplumber
import csv

def extract_data_from_pdf(pdf_file_path):
    with pdfplumber.open(pdf_file_path) as pdf:
        extracted_data = []

        # For Extracting header data
        first_page = pdf.pages[0]
        header_data = first_page.extract_text().split('\n')
        extracted_data.append(header_data)

        # For Extracting  table data
        for page in pdf.pages:
            tables = page.extract_tables()
            for table in tables:
                extracted_data.extend(table)

    return extracted_data

# def save_data_to_csv(data, csv_file_path):
#     with open(csv_file_path, 'w', newline='') as csv_file:
#         writer = csv.writer(csv_file)
#         writer.writerows(data)

def save_data_to_csv(data, csv_file_path):
    with open(csv_file_path, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerows(data)

if __name__ == '__main__':
    pdf_file_path = 'sampletabledata.pdf'
    csv_file_path = 'sampletab.csv'

    extracted_data = extract_data_from_pdf(pdf_file_path)
    save_data_to_csv(extracted_data, csv_file_path)
